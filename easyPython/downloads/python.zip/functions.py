import requests #pip3 install requests
from bs4 import BeautifulSoup #pip install BeautifulSoup4
import webbrowser
import re
import string
import time
import random
import ctypes
import sys

##### To Use this - from functions import *

TAG_RE = re.compile(r'<[^>]+>')

def debug(messageToPrint):
    print(messageToPrint)

def wait(seconds):
    time.sleep(seconds)

def clearScreen():
	for x in range(0, 200):
		print(" ")

def removeHTML(text):
	return TAG_RE.sub('', text)

def quitApplication():
    raise SystemExit

def toString(var):
    stringVar = str(var)
    return stringVar

def openWebsite(urlToOpen):
        webbrowser.open_new_tab(urlToOpen)

def getUserInput(messageToShow):
    return input(messageToShow)

def setTitle(title):
    ctypes.windll.kernel32.SetConsoleTitleW(title)

def contains(string, stringToCompare):
    if string in stringToCompare:
        return True
    else:
        return False

def getElementByClassFromWebsite(url, elementType, className):
    URL = url
    page = requests.get(URL)
    soup = BeautifulSoup(page.content, 'html.parser')

    info = soup.findAll(elementType, {"class": className})
    return info