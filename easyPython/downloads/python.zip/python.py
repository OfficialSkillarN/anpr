from functions import *

### Functions list ###
#setTitle("Title") - Sets title
#quitApplication() - Quits
#clearScreen() - Clears the screen
#debug("Message to debug") - Prints a debug message
#removeHTML(stringToRemoveHTMLCodeFrom) - Removes HTML tags
#toString(variableName) - Converts any variable to string
#openWebsite(url) - Opens a website
#getUserInput(prompt) - Prompts the user with input
#contains(stringTwo, stringOne) - Checks if stringTwo contains stringOne
#getElementByClassFromWebsite("HTMLElement", "className") - Finds every object with the specified element AND className
#wait(seconds) - Waits X second